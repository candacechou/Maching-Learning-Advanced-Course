"""
File for task 2.8 in assignment 2 of DD2434.
See README for more instructions and information on generating/loading trees.
"""

import numpy as np
from Tree import Tree
import sys
def test_binary_trees(seed_val=0, k=2, num_nodes=5):
    """
    Test function for generating binary trees from Tree.py and printing topology.
    :param: seed_val: Numpy seed.
    :param: k: Number of possible values for a node.
    :param: num_nodes: Number of total nodes in the tree. Has to be odd, or it will auto correct to +1.
    :return: binary_tree: A generated binary tree. Tree object from Tree.py.
    """
    binary_tree = Tree()
    binary_tree.create_random_binary_tree(seed_val=seed_val, k=k, num_nodes=num_nodes)

    # Print tree
    binary_tree.print()

    # Print topology
    binary_tree.print_topology()

    return binary_tree

def load_tree():
    """
    Function for loading the tree for the assignment.
    :return: Loaded tree
    """
    binary_tree = Tree()
    binary_tree.load_tree('tree_task_2_8')

    # Print tree
    binary_tree.print()

    # Print topology
    binary_tree.print_topology()

    return binary_tree

def load_interval(path='interval_task_2_8.npy', str=False):
    """
    Function for loading the interval dictionary for the assignment.
    :param: str: Load from text file or numpy file.
    :return: Dictionary of interval.
    """
    if not str:
        mode_dict = np.load(path, allow_pickle=True).item()
    else:
        from ast import literal_eval
        with open(path, "r") as file:
            data = file.readlines()
        mode_dict = literal_eval(data[0])
    return mode_dict

def test_node_sample_proportion(dict, tree, n=1000):
    """
    Function for sampling n leaf sets and computing, for each leaf node,
    the proportion of samples that are in the provided interval.
    :param: dict: Interval dictionary containing node keys and lists of possible node values.
    :param: tree: Generated tree. Tree object from Tree.py.
    :param: n: Number of samples.
    :return: Dictionary with proportion of samples that are in the interval for each node.
    """
    n_samples = {}
    for i in range(n):
        # leaf_samples = <SAMPLING FUNCTION HERE>
        leaf_samples = odd_sum_sampling(tree.get_topology_array(), tree.get_theta_array())
        if i == 0:
            n_samples = {key: 0 for key in leaf_samples.keys()}
        for key, val in leaf_samples.items():
            if val in dict[key]:
                n_samples[key] += 1/n
    return n_samples

def test_sample_proportion(dict, tree, n=1000):
    """
    Function for sampling n leaf sets and computing the proportion of sets that are in the interval dict.
    :param: dict: Interval dictionary containing node keys and lists of possible node values.
    :param: tree: Generated tree. Tree object from Tree.py.
    :param: n: Number of samples.
    :return: Proportion of samples that are in interval dict.
    """
    n_samples = 0
    even = 0
    odd = 0
    for i in range(n):
        # leaf_samples = <SAMPLING FUNCTION HERE>
        leaf_samples = odd_sum_sampling(tree.get_topology_array(), tree.get_theta_array())
        flag = 0
        print('leaf_samples',leaf_samples)
        items = list(leaf_samples.values())
        print('sum:\t ', np.nansum(items))
        if np.nansum(items)%2 == 0:
            even +=1
        else :
            odd +=1
        # print('dict,', dict)
        for key, val in leaf_samples.items():
            if val not in dict[key]:
                flag = 1
        if flag == 0:
            n_samples += 1
    print('odd_sum_ratio:', odd * 1.0/n)
    return n_samples/n

def tree_DP(tree_topology, theta,node):
    # TODO: Implement algorithm for dynamic programming
    #likelihood_odd1 = calculate_s(tree_topology, theta, node, 1)
    c = 1.2
    likelihood_odd = calculate_s(tree_topology, theta, node, 0)
    #likelihood =  likelihood_odd + likelihood_odd1
    return   likelihood_odd / np.sum(likelihood_odd)

def calculate_s(tree_topology, theta, node,even):
    children = find_children(tree_topology, node)
    c = 10
    ### if current node is even and it is leave
    k = theta.shape[1]
    if len(children) == 0:
        s = np.zeros((k, 1))
        if even == 1:
            for i in range(k):
                if i % 2 == 0:
                    s[i] = 1
                else:
                    s[i] = 0
        else:
            for i in range(k):
                if i % 2 == 1:
                    s[i] = c
                else:
                    s[i] = 0
        return s / np.sum(s)
    else:

        theta1 = theta[children[0]]
        theta2 = theta[children[1]]
        theta1 = np.array(theta1.tolist())
        theta2 = np.array(theta2.tolist())
        if even == 1:  ## 2 for even or 2 for odd
            s1 = calculate_s(tree_topology, theta, children[0], 0)
            s2 = calculate_s(tree_topology, theta, children[1], 0)
            likelihood = (1 - np.dot(theta1, s1)) * (1 - np.dot(theta2, s2))
            s1 = calculate_s(tree_topology, theta, children[0], 0)
            s2 = calculate_s(tree_topology, theta, children[1], 0)
            likelihood += c * np.dot(theta1, s1) * c * np.dot(theta2, s2)
        else:  ## 1 even 1 odd
            s1 = calculate_s(tree_topology, theta, children[0], 0)
            s2 = calculate_s(tree_topology, theta, children[1], 0)
            likelihood = c * np.dot(theta1, s1) * (1 - np.dot(theta2, s2))
            s1 = calculate_s(tree_topology, theta, children[0], 0)
            s2 = calculate_s(tree_topology, theta, children[1], 0)
            likelihood += (1 - np.dot(theta1, s1)) * c * np.dot(theta2, s2)
        likelihood = likelihood / np.sum(likelihood)
        return likelihood


def find_children(tree_topology, node):
    children = []
    children = np.argwhere(tree_topology == node)
    if len(children) == 0:
        return []
    else:
        children = children.reshape((2,))

        return list(children)

def odd_sum_sampling(topology, theta):
    num_nodes = len(topology)
    samples = [0] * num_nodes
    filtered_samples = {}
    cur_sample = []
    visit_list = [0]
    here = []
    c = 1
    while len(visit_list) != 0:
        cur_node = visit_list[0]
        children = find_children(topology, cur_node)
        visit_list = visit_list[1:] + children
        par_node = topology[cur_node]
        if len(children) == 0:
            filtered_samples[str(cur_node)] = samples[int(cur_node)]
        else:
            if cur_node == 0:
                a = tree_DP(topology,theta,0)
                # b = np.array(theta[0].reshape(5,1))
                cat = a * np.array(theta[0]).reshape(1,5)
                cat = cat[0]

                cat = cat / np.sum(cat)

                cur_sample = np.random.choice(np.arange(5), p = cat.tolist())
                samples[int(cur_node)] = cur_sample
            else:
                cur_sample = samples[int(cur_node)]
            if cur_sample % 2 == 0:  ### even
                test = np.random.randint(2)
                if test == 1:

                    cat1 = c * calculate_s(topology, theta, children[0], 0) * theta[children[0]][cur_sample].reshape(5,1)
                    cat2 = c * calculate_s(topology, theta, children[1], 0) * theta[children[1]][cur_sample].reshape(5,1)
                else:
                    cat1 = (1 - calculate_s(topology, theta, children[0], 0)) * theta[children[0]][cur_sample].reshape(5,1)
                    cat2 = (1 - calculate_s(topology, theta, children[1], 0)) * theta[children[1]][cur_sample].reshape(5,1)
                cat1 = cat1.reshape(1, 5) / np.sum(cat1)
                cat2 = cat2.reshape(1, 5) / np.sum(cat2)
                cat1 = cat1[0]
                cat2 = cat2[0]
                cur_sample = np.random.choice(np.arange(5), p = cat1.tolist())
                samples[int(children[0])] = cur_sample
                cur_sample = np.random.choice(np.arange(5), p = cat2.tolist())
                samples[int(children[1])] = cur_sample
            else:
                test = np.random.randint(2)
                if test == 1:
                    cat1 = c * calculate_s(topology, theta, children[0], 0)   * theta[children[0]][cur_sample].reshape(5,1)
                    cat2 = (1 - calculate_s(topology, theta, children[1], 0)) * theta[children[1]][cur_sample].reshape(5,1)
                else:
                    cat1 = (1 - calculate_s(topology, theta, children[0], 0)) * theta[children[0]][cur_sample].reshape(5,1)
                    cat2 = c * calculate_s(topology, theta, children[1], 0) * theta[children[1]][cur_sample].reshape(5,1)
                cat1 = cat1.reshape(1, 5) / np.sum(cat1)
                cat2 = cat2.reshape(1, 5) / np.sum(cat2)
                cat1 = cat1[0]
                cat2 = cat2[0]
                cur_sample = np.random.choice(np.arange(5), p = cat1.tolist())
                samples[int(children[0])] = cur_sample
                cur_sample = np.random.choice(np.arange(5), p=cat2.tolist())
                samples[int(children[1])] = cur_sample
    return filtered_samples

def main():
    # Test tree
    binary_tree = test_binary_trees(seed_val =0, k=2, num_nodes = 7)

    # Load tree
    binary_tree = load_tree()
    #print(tree_DP(binary_tree.get_topology_array(), binary_tree.get_theta_array(),0))

    # Load interval dictionary
    most_freq_dict = load_interval('interval_task_2_8.npy')
    node_most_freq_dict = load_interval('node_interval_task_2_8.npy')
    a = test_sample_proportion(most_freq_dict, binary_tree, n=1000)
    b = test_node_sample_proportion(node_most_freq_dict, binary_tree, n=1000)
    #print(most_freq_dict)
    print('sample ratio:' ,a)
    print('node ratio:',b)



if __name__ == "__main__":
    main()