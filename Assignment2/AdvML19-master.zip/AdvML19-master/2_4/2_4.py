import random
import numpy as np
from scipy.special import gamma
import scipy.stats
import matplotlib.pyplot as plt
## data generation
def generate_data(mean,var,N):
    Data = np.random.normal(mean,var,N)
    return Data


def true_posterior(D,N,mu,tau,mu0,L0,a0,b0):
    sumup        = np.sum(D**2) - 2 * np.sum(D) * mu + N * mu**2
    P_Likelihood = (tau / (2 * np.pi))**(N/2) * np.exp(-(tau/2) * sumup)
    sigma        = 1/(L0 * tau)
    exponent     = - (mu0 - mu)**2 / (2 * sigma)
    P_prior      =  1 / (np.sqrt(2 * np.pi * sigma)) * np.exp(exponent)
    P_tau        = (1 /gamma(a0)) * (b0**a0) * (tau**(a0-1)) * np.exp(-b0 * tau)
    # print(P_Likelihood)
    # print(P_prior)
    # print(P_tau)
    return P_Likelihood * P_prior * P_tau

def plot_posterior(Ptrue,Pesti,mu,tau):
    plt.figure()
    left = 0.1  # the left side of the subplots of the figure
    right = 0.95   # the right side of the subplots of the figure
    bottom = 0.1  # the bottom of the subplots of the figure
    top = 0.95    # the top of the subplots of the figure
    wspace = 0.25  # the amount of width reserved for space between subplots,
                   # expressed as a fraction of the average axis width
    hspace = 0.25
    plt.subplots_adjust(left, bottom, right, top, wspace, hspace)
    
    for i in range(0,6):
        plt.subplot(2,3,i+1)
        plt.tight_layout()
        plt.contour(mu,tau,Ptrue,colors = 'b')
        plt.contour(mu,tau,Pesti[i],colors = 'r')
        titles = str(i) + 'st iter' 
        plt.title(titles)
        plt.xlabel(r'$\mu$')
        plt.ylabel(r'$\tau$')
        

    
    plt.show()

def estimate_posterior(mu,muN,LN,tau,aN,bN):
    exponent = - LN * (mu-muN)**2 / 2
    q  = (np.sqrt(LN/(2 * np.pi)) * np.exp(exponent)) * ((1.0 /gamma(aN)) * (bN**aN) * (tau**(aN-1)) * np.exp(- bN * tau))
    return q

def VI_algorithm(D,N,L0,mu0,a0,b0,bN,LN,mu,tau):
    iter = 6
    i    = 0
    Post_esti = []
    aN = a0 + (N+1)/2.0
    xbar = np.sum(D) / N
    mu_N = (L0 * mu0 + N * xbar) /(L0 + N)
    # print('aN: ',aN)
    # print('mu_N: ',mu_N)
    while(i < iter):
        ## mu_N

        ## EXPECT VALUES
        E_tau = aN / bN
        
        E_mu  = mu_N
        E_mu2 =  mu_N**2 + 1 / LN
        LN    = (L0 + N) * E_tau
        bN =  b0 + 0.5 * (np.sum(D**2) + L0 * (mu0**2)) - \
                   (np.sum(D) + mu0 * L0) * E_mu + \
                   0.5 * (L0 + N) * E_mu2
        ## store for plotting
        esti = estimate_posterior(mu,mu_N,LN,tau,aN,bN)
        Post_esti.append(esti)
        i = i + 1
    return Post_esti

N    = 10
mean = 0
var  = 1
Data = generate_data(mean,var,N)
## parameters

mu_0 = 0.01
a_0  = 2
b_0  = 5
L_0  = 10 ## lambda 0
bN   = 0.4
LN   = 0.2

## some tau and some mu

tau = np.linspace(0,4,100)
mu  = np.linspace(-2,2,100)
tauv,muv = np.meshgrid(tau,mu)
Ptrue = true_posterior(Data,N,muv,tauv,mu_0,L_0,a_0,b_0)
# plt.figure()
# plt.contour(tau,mu,Ptrue)
# plt.show()
Pesti = VI_algorithm(Data,N,L_0,mu_0,a_0,b_0,bN,LN,muv,tauv)

plot_posterior(Ptrue,Pesti,mu,tau)